<?php
$namaServer = "localhost";
$username = "id17810887_aldian";
$password = "Krh)uRn(3<7U_oJH";
$namaDB = "id17810887_utsweb";

//Membuat Koneksi
$conn = mysqli_connect($namaServer, $username, $password, $namaDB);
//check koneksi
if (!$conn) {
    die("Koneksi Gagal");
}
?>